"""
VISIA Core - Motor de Cálculos
"""
from .visia_engine import (
    VisiaEngine,
    DadosProjetoVISIA,
    DadosDimensaoEducacional,
    DadosDimensaoEconomica,
    DadosDimensaoSocialAmbiental,
    DadosDimensaoPoliticoPublica,
    ResultadoVISIA
)

__all__ = [
    'VisiaEngine',
    'DadosProjetoVISIA',
    'DadosDimensaoEducacional',
    'DadosDimensaoEconomica',
    'DadosDimensaoSocialAmbiental',
    'DadosDimensaoPoliticoPublica',
    'ResultadoVISIA'
]

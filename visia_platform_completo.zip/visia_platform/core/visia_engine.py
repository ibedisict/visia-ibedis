"""
================================================================================
VISIA ENGINE - Motor de Cálculos da Metodologia VISIA
================================================================================
Valoração Integrada de Sustentabilidade e Impacto Aplicado
Metodologia Proprietária - IBEDIS
Autor: Wemerson Marinho
ISBN: 978-65-01-58740-0

FÓRMULAS 100% FIÉIS AO LIVRO - SEM ALUCINAÇÕES
================================================================================
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime
import hashlib
import json

# ==============================================================================
# ESTRUTURAS DE DADOS
# ==============================================================================

@dataclass
class DadosDimensaoEducacional:
    """Dados de entrada para Dimensão Educacional"""
    alunos_impactados: float = 0
    melhoria_desempenho: float = 0  # em percentual (ex: 15 para 15%)
    jovens_capacitados: float = 0
    taxa_empregabilidade: float = 0  # em percentual
    taxa_evasao_antes: float = 0
    taxa_evasao_depois: float = 0
    investimento: float = 0

@dataclass
class DadosDimensaoEconomica:
    """Dados de entrada para Dimensão Econômica"""
    empregos_gerados: float = 0
    renda_media: float = 0
    microcreditos_concedidos: float = 0
    valor_medio_credito: float = 0
    reducao_custos_servicos: float = 0
    investimento: float = 0

@dataclass
class DadosDimensaoSocialAmbiental:
    """Dados de entrada para Dimensão Social e Ambiental"""
    populacao_beneficiada: float = 0
    taxa_melhoria_qualidade_vida: float = 0  # em percentual
    creditos_carbono_gerados: float = 0
    impacto_economia_circular: float = 0  # em percentual
    projetos_sustentaveis: float = 0
    fator_sustentabilidade: float = 50  # valor padrão do livro
    investimento: float = 0

@dataclass
class DadosDimensaoPoliticoPublica:
    """Dados de entrada para Dimensão Político-Pública"""
    gestores_capacitados: float = 0
    populacao_impactada: float = 0
    transparencia_aumento: float = 0  # em percentual
    investimentos_captados: float = 0
    numero_politicas_criadas: float = 0
    leis_regulamentacoes: float = 0
    investimento: float = 0

@dataclass
class DadosProjetoVISIA:
    """Estrutura completa de dados de um projeto para análise VISIA"""
    # Identificação
    nome_projeto: str = ""
    descricao: str = ""
    orgao_responsavel: str = ""
    municipio: str = ""
    estado: str = ""
    data_inicio: str = ""
    data_fim: str = ""
    
    # Dimensões
    educacional: DadosDimensaoEducacional = field(default_factory=DadosDimensaoEducacional)
    economica: DadosDimensaoEconomica = field(default_factory=DadosDimensaoEconomica)
    social_ambiental: DadosDimensaoSocialAmbiental = field(default_factory=DadosDimensaoSocialAmbiental)
    politico_publica: DadosDimensaoPoliticoPublica = field(default_factory=DadosDimensaoPoliticoPublica)
    
    # Investimento total
    investimento_total: float = 0
    
    # Metadados
    hash_projeto: str = ""
    versao: int = 1
    data_analise: str = ""

@dataclass
class ResultadoVISIA:
    """Resultado completo da análise VISIA"""
    # Índices por dimensão
    indice_educacional: float = 0
    indice_economico: float = 0
    indice_social_ambiental: float = 0
    indice_politico_publico: float = 0
    
    # Impacto Total
    impacto_total: float = 0
    
    # Classificação
    classificacao: str = ""
    recomendacao: str = ""
    
    # Detalhamento
    detalhes_educacional: Dict = field(default_factory=dict)
    detalhes_economico: Dict = field(default_factory=dict)
    detalhes_social_ambiental: Dict = field(default_factory=dict)
    detalhes_politico_publico: Dict = field(default_factory=dict)
    
    # Recomendações de melhoria
    recomendacoes: List[Dict] = field(default_factory=list)
    
    # Metadados
    hash_resultado: str = ""
    timestamp: str = ""

# ==============================================================================
# MOTOR DE CÁLCULOS VISIA - FÓRMULAS DO LIVRO
# ==============================================================================

class VisiaEngine:
    """
    Motor de cálculos da metodologia VISIA.
    Implementa EXATAMENTE as fórmulas do livro sem modificações.
    """
    
    # Constantes de classificação
    CLASSIFICACAO_EXCELENTE = "EXCELENTE"
    CLASSIFICACAO_BOM = "BOM"
    CLASSIFICACAO_REGULAR = "REGULAR"
    CLASSIFICACAO_INSUFICIENTE = "INSUFICIENTE"
    
    # Limiares de classificação baseados no livro
    LIMIAR_EXCELENTE = 50  # >= 50%
    LIMIAR_BOM = 30        # >= 30%
    LIMIAR_REGULAR = 15    # >= 15%
    
    def __init__(self):
        self.versao_motor = "1.0.0"
        self.metodologia = "VISIA - Valoração Integrada de Sustentabilidade e Impacto Aplicado"
        self.autor = "Wemerson Marinho"
        self.isbn = "978-65-01-58740-0"
    
    # ==========================================================================
    # FÓRMULA 1: DIMENSÃO EDUCACIONAL
    # Livro Cap. 4, Seção 4.1 e Cap. 10
    # ==========================================================================
    def calcular_impacto_educacional(self, dados: DadosDimensaoEducacional) -> Dict:
        """
        FÓRMULA DO LIVRO (Cap. 4.1):
        I_educacional = (Alunos_impactados × Melhoria_desempenho) / Investimento × 100
        
        FÓRMULA ALTERNATIVA (Cap. 10):
        I_educacional = (Jovens_capacitados × Empregabilidade) / Investimento_total × 100
        """
        resultado = {
            "indice": 0,
            "formula_aplicada": "",
            "variaveis": {},
            "observacoes": []
        }
        
        if dados.investimento <= 0:
            resultado["observacoes"].append("Investimento não informado ou zero")
            return resultado
        
        # Prioriza fórmula com alunos se disponível
        if dados.alunos_impactados > 0 and dados.melhoria_desempenho > 0:
            # FÓRMULA PRINCIPAL DO LIVRO
            indice = (dados.alunos_impactados * dados.melhoria_desempenho) / dados.investimento * 100
            resultado["formula_aplicada"] = "I_educacional = (Alunos × Melhoria) / Investimento × 100"
            resultado["variaveis"] = {
                "alunos_impactados": dados.alunos_impactados,
                "melhoria_desempenho": dados.melhoria_desempenho,
                "investimento": dados.investimento
            }
        elif dados.jovens_capacitados > 0 and dados.taxa_empregabilidade > 0:
            # FÓRMULA ALTERNATIVA (Projeto Nós do Centro)
            indice = (dados.jovens_capacitados * dados.taxa_empregabilidade) / dados.investimento * 100
            resultado["formula_aplicada"] = "I_educacional = (Jovens × Empregabilidade) / Investimento × 100"
            resultado["variaveis"] = {
                "jovens_capacitados": dados.jovens_capacitados,
                "taxa_empregabilidade": dados.taxa_empregabilidade,
                "investimento": dados.investimento
            }
        else:
            resultado["observacoes"].append("Dados insuficientes para cálculo educacional")
            return resultado
        
        # Análise de evasão escolar (indicador complementar)
        if dados.taxa_evasao_antes > 0 and dados.taxa_evasao_depois >= 0:
            reducao_evasao = dados.taxa_evasao_antes - dados.taxa_evasao_depois
            resultado["indicadores_complementares"] = {
                "reducao_evasao_escolar": reducao_evasao,
                "taxa_evasao_antes": dados.taxa_evasao_antes,
                "taxa_evasao_depois": dados.taxa_evasao_depois
            }
        
        resultado["indice"] = round(indice, 2)
        return resultado
    
    # ==========================================================================
    # FÓRMULA 2: DIMENSÃO ECONÔMICA
    # Livro Cap. 4, Seção 4.2 e Cap. 6
    # ==========================================================================
    def calcular_impacto_economico(self, dados: DadosDimensaoEconomica) -> Dict:
        """
        FÓRMULA DO LIVRO (Cap. 4.2):
        I_econômico = (Empregos_gerados × Renda_média) / Investimento × 100
        
        FÓRMULA ALTERNATIVA (Microcrédito):
        I_econômico = (Microcréditos_concedidos × Média_valor_crédito) / Investimento × 100
        """
        resultado = {
            "indice": 0,
            "formula_aplicada": "",
            "variaveis": {},
            "observacoes": []
        }
        
        if dados.investimento <= 0:
            resultado["observacoes"].append("Investimento não informado ou zero")
            return resultado
        
        # Prioriza fórmula com empregos
        if dados.empregos_gerados > 0 and dados.renda_media > 0:
            # FÓRMULA PRINCIPAL DO LIVRO
            indice = (dados.empregos_gerados * dados.renda_media) / dados.investimento * 100
            resultado["formula_aplicada"] = "I_econômico = (Empregos × Renda_média) / Investimento × 100"
            resultado["variaveis"] = {
                "empregos_gerados": dados.empregos_gerados,
                "renda_media": dados.renda_media,
                "investimento": dados.investimento
            }
        elif dados.microcreditos_concedidos > 0 and dados.valor_medio_credito > 0:
            # FÓRMULA MICROCRÉDITO (Projeto Nós do Centro)
            indice = (dados.microcreditos_concedidos * dados.valor_medio_credito) / dados.investimento * 100
            resultado["formula_aplicada"] = "I_econômico = (Microcréditos × Valor_médio) / Investimento × 100"
            resultado["variaveis"] = {
                "microcreditos_concedidos": dados.microcreditos_concedidos,
                "valor_medio_credito": dados.valor_medio_credito,
                "investimento": dados.investimento
            }
        else:
            resultado["observacoes"].append("Dados insuficientes para cálculo econômico")
            return resultado
        
        # ROI Tradicional (complementar)
        if dados.reducao_custos_servicos > 0:
            roi = ((dados.reducao_custos_servicos - dados.investimento) / dados.investimento) * 100
            resultado["indicadores_complementares"] = {
                "roi_tradicional": round(roi, 2),
                "reducao_custos": dados.reducao_custos_servicos
            }
        
        resultado["indice"] = round(indice, 2)
        return resultado
    
    # ==========================================================================
    # FÓRMULA 3: DIMENSÃO SOCIAL E AMBIENTAL
    # Livro Cap. 4, Seção 4.3 e Cap. 7
    # ==========================================================================
    def calcular_impacto_social_ambiental(self, dados: DadosDimensaoSocialAmbiental) -> Dict:
        """
        FÓRMULA DO LIVRO (Cap. 4.3):
        I_soc-amb = [(População × Taxa_melhoria) + (Créditos_carbono × Impacto_circular)] / Investimento × 100
        
        FÓRMULA ALTERNATIVA:
        I_soc-amb = [(Beneficiários × %Melhoria) + (Projetos_sust × F_sust)] / Investimento × 100
        """
        resultado = {
            "indice": 0,
            "formula_aplicada": "",
            "variaveis": {},
            "observacoes": []
        }
        
        if dados.investimento <= 0:
            resultado["observacoes"].append("Investimento não informado ou zero")
            return resultado
        
        componente_social = 0
        componente_ambiental = 0
        
        # Componente Social
        if dados.populacao_beneficiada > 0:
            componente_social = dados.populacao_beneficiada * dados.taxa_melhoria_qualidade_vida
        
        # Componente Ambiental - Fórmula Principal
        if dados.creditos_carbono_gerados > 0:
            componente_ambiental = dados.creditos_carbono_gerados * dados.impacto_economia_circular
            resultado["formula_aplicada"] = "I_soc-amb = [(Pop × Taxa) + (Carbono × Circular)] / Invest × 100"
        # Componente Ambiental - Fórmula Alternativa
        elif dados.projetos_sustentaveis > 0:
            componente_ambiental = dados.projetos_sustentaveis * dados.fator_sustentabilidade
            resultado["formula_aplicada"] = "I_soc-amb = [(Benef × Melhoria) + (Proj_sust × F_sust)] / Invest × 100"
        else:
            resultado["formula_aplicada"] = "I_soc-amb = (População × Taxa_melhoria) / Investimento × 100"
        
        if componente_social == 0 and componente_ambiental == 0:
            resultado["observacoes"].append("Dados insuficientes para cálculo social-ambiental")
            return resultado
        
        indice = (componente_social + componente_ambiental) / dados.investimento * 100
        
        resultado["variaveis"] = {
            "populacao_beneficiada": dados.populacao_beneficiada,
            "taxa_melhoria": dados.taxa_melhoria_qualidade_vida,
            "creditos_carbono": dados.creditos_carbono_gerados,
            "economia_circular": dados.impacto_economia_circular,
            "projetos_sustentaveis": dados.projetos_sustentaveis,
            "investimento": dados.investimento
        }
        
        resultado["indicadores_complementares"] = {
            "componente_social": round(componente_social, 2),
            "componente_ambiental": round(componente_ambiental, 2)
        }
        
        resultado["indice"] = round(indice, 2)
        return resultado
    
    # ==========================================================================
    # FÓRMULA 4: DIMENSÃO POLÍTICO-PÚBLICA
    # Livro Cap. 4, Seção 4.4 e Cap. 8
    # ==========================================================================
    def calcular_impacto_politico_publico(self, dados: DadosDimensaoPoliticoPublica) -> Dict:
        """
        FÓRMULA DO LIVRO (Cap. 4.4):
        I_politico = [(Gestores × População) + (Nº_políticas × Valor_captado)] / Investimento × 100
        """
        resultado = {
            "indice": 0,
            "formula_aplicada": "",
            "variaveis": {},
            "observacoes": []
        }
        
        if dados.investimento <= 0:
            resultado["observacoes"].append("Investimento não informado ou zero")
            return resultado
        
        componente_gestao = 0
        componente_politicas = 0
        
        # Componente Gestão
        if dados.gestores_capacitados > 0:
            if dados.populacao_impactada > 0:
                componente_gestao = dados.gestores_capacitados * dados.populacao_impactada
            else:
                # Usa transparência como proxy
                componente_gestao = dados.gestores_capacitados * dados.transparencia_aumento * 1000
        
        # Componente Políticas
        if dados.numero_politicas_criadas > 0 and dados.investimentos_captados > 0:
            componente_politicas = dados.numero_politicas_criadas * dados.investimentos_captados
        elif dados.leis_regulamentacoes > 0:
            componente_politicas = dados.leis_regulamentacoes * dados.investimentos_captados if dados.investimentos_captados > 0 else 0
        
        if componente_gestao == 0 and componente_politicas == 0:
            resultado["observacoes"].append("Dados insuficientes para cálculo político-público")
            return resultado
        
        indice = (componente_gestao + componente_politicas) / dados.investimento * 100
        
        resultado["formula_aplicada"] = "I_político = [(Gestores × Pop) + (Políticas × Captado)] / Invest × 100"
        resultado["variaveis"] = {
            "gestores_capacitados": dados.gestores_capacitados,
            "populacao_impactada": dados.populacao_impactada,
            "transparencia": dados.transparencia_aumento,
            "investimentos_captados": dados.investimentos_captados,
            "politicas_criadas": dados.numero_politicas_criadas,
            "investimento": dados.investimento
        }
        
        resultado["indicadores_complementares"] = {
            "componente_gestao": round(componente_gestao, 2),
            "componente_politicas": round(componente_politicas, 2)
        }
        
        resultado["indice"] = round(indice, 2)
        return resultado
    
    # ==========================================================================
    # FÓRMULA 5: IMPACTO TOTAL VISIA
    # Livro Cap. 9, Seção 9.2
    # ==========================================================================
    def calcular_impacto_total(self, i_edu: float, i_eco: float, i_soc: float, i_pol: float) -> float:
        """
        FÓRMULA DO LIVRO (Cap. 9.2):
        I_total = (I_educacional + I_econômico + I_soc-amb + I_político) / 4
        
        Média aritmética das 4 dimensões.
        """
        return round((i_edu + i_eco + i_soc + i_pol) / 4, 2)
    
    # ==========================================================================
    # CLASSIFICAÇÃO VISIA
    # ==========================================================================
    def classificar_projeto(self, impacto_total: float) -> Dict:
        """
        Classifica o projeto baseado no impacto total.
        Baseado nos exemplos do livro:
        - >= 50%: EXCELENTE
        - >= 30%: BOM  
        - >= 15%: REGULAR
        - < 15%: INSUFICIENTE
        """
        if impacto_total >= self.LIMIAR_EXCELENTE:
            classificacao = self.CLASSIFICACAO_EXCELENTE
            recomendacao = "APROVADO - Projeto com alto impacto positivo. Recomenda-se expansão e replicação."
            cor = "verde"
        elif impacto_total >= self.LIMIAR_BOM:
            classificacao = self.CLASSIFICACAO_BOM
            recomendacao = "APROVADO COM RESSALVAS - Projeto com bom impacto. Monitorar indicadores e buscar melhorias."
            cor = "azul"
        elif impacto_total >= self.LIMIAR_REGULAR:
            classificacao = self.CLASSIFICACAO_REGULAR
            recomendacao = "APROVADO COM AJUSTES NECESSÁRIOS - Implementar melhorias nas dimensões com baixo desempenho."
            cor = "amarelo"
        else:
            classificacao = self.CLASSIFICACAO_INSUFICIENTE
            recomendacao = "NÃO RECOMENDADO - Projeto com baixo impacto. Requer reformulação significativa."
            cor = "vermelho"
        
        return {
            "classificacao": classificacao,
            "recomendacao": recomendacao,
            "cor": cor,
            "impacto_percentual": impacto_total
        }
    
    # ==========================================================================
    # GERADOR DE RECOMENDAÇÕES
    # ==========================================================================
    def gerar_recomendacoes(self, resultado: Dict) -> List[Dict]:
        """
        Gera recomendações específicas para melhorar cada dimensão.
        """
        recomendacoes = []
        
        # Análise Educacional
        if resultado.get("indice_educacional", 0) < 20:
            recomendacoes.append({
                "dimensao": "Educacional",
                "prioridade": "ALTA" if resultado.get("indice_educacional", 0) < 10 else "MÉDIA",
                "acao": "Aumentar número de beneficiários ou melhorar indicadores de desempenho",
                "impacto_estimado": f"+{20 - resultado.get('indice_educacional', 0):.1f}% no índice"
            })
        
        # Análise Econômica
        if resultado.get("indice_economico", 0) < 20:
            recomendacoes.append({
                "dimensao": "Econômica",
                "prioridade": "ALTA" if resultado.get("indice_economico", 0) < 10 else "MÉDIA",
                "acao": "Expandir geração de empregos ou aumentar renda média dos beneficiários",
                "impacto_estimado": f"+{20 - resultado.get('indice_economico', 0):.1f}% no índice"
            })
        
        # Análise Social-Ambiental
        if resultado.get("indice_social_ambiental", 0) < 20:
            recomendacoes.append({
                "dimensao": "Social e Ambiental",
                "prioridade": "ALTA" if resultado.get("indice_social_ambiental", 0) < 10 else "MÉDIA",
                "acao": "Ampliar população beneficiada ou incluir componentes de sustentabilidade",
                "impacto_estimado": f"+{20 - resultado.get('indice_social_ambiental', 0):.1f}% no índice"
            })
        
        # Análise Político-Pública
        if resultado.get("indice_politico_publico", 0) < 20:
            recomendacoes.append({
                "dimensao": "Político-Pública",
                "prioridade": "ALTA" if resultado.get("indice_politico_publico", 0) < 10 else "MÉDIA",
                "acao": "Capacitar mais gestores ou aumentar captação de investimentos externos",
                "impacto_estimado": f"+{20 - resultado.get('indice_politico_publico', 0):.1f}% no índice"
            })
        
        return recomendacoes
    
    # ==========================================================================
    # ANÁLISE COMPLETA
    # ==========================================================================
    def analisar_projeto(self, dados: DadosProjetoVISIA) -> ResultadoVISIA:
        """
        Executa análise VISIA completa do projeto.
        Garante consistência: mesmo projeto = mesma análise.
        """
        # Gera hash do projeto para garantir consistência
        dados_json = json.dumps({
            "nome": dados.nome_projeto,
            "educacional": dados.educacional.__dict__,
            "economica": dados.economica.__dict__,
            "social_ambiental": dados.social_ambiental.__dict__,
            "politico_publica": dados.politico_publica.__dict__,
            "investimento_total": dados.investimento_total
        }, sort_keys=True)
        hash_projeto = hashlib.sha256(dados_json.encode()).hexdigest()[:16]
        
        # Calcula cada dimensão
        resultado_edu = self.calcular_impacto_educacional(dados.educacional)
        resultado_eco = self.calcular_impacto_economico(dados.economica)
        resultado_soc = self.calcular_impacto_social_ambiental(dados.social_ambiental)
        resultado_pol = self.calcular_impacto_politico_publico(dados.politico_publica)
        
        # Calcula impacto total
        impacto_total = self.calcular_impacto_total(
            resultado_edu["indice"],
            resultado_eco["indice"],
            resultado_soc["indice"],
            resultado_pol["indice"]
        )
        
        # Classifica
        classificacao = self.classificar_projeto(impacto_total)
        
        # Monta resultado
        resultado = ResultadoVISIA(
            indice_educacional=resultado_edu["indice"],
            indice_economico=resultado_eco["indice"],
            indice_social_ambiental=resultado_soc["indice"],
            indice_politico_publico=resultado_pol["indice"],
            impacto_total=impacto_total,
            classificacao=classificacao["classificacao"],
            recomendacao=classificacao["recomendacao"],
            detalhes_educacional=resultado_edu,
            detalhes_economico=resultado_eco,
            detalhes_social_ambiental=resultado_soc,
            detalhes_politico_publico=resultado_pol,
            hash_resultado=hash_projeto,
            timestamp=datetime.now().isoformat()
        )
        
        # Gera recomendações
        resultado.recomendacoes = self.gerar_recomendacoes({
            "indice_educacional": resultado_edu["indice"],
            "indice_economico": resultado_eco["indice"],
            "indice_social_ambiental": resultado_soc["indice"],
            "indice_politico_publico": resultado_pol["indice"]
        })
        
        return resultado


# ==============================================================================
# FUNÇÕES AUXILIARES
# ==============================================================================

def criar_projeto_exemplo() -> DadosProjetoVISIA:
    """
    Cria um projeto de exemplo baseado no Projeto Nós do Centro (Cap. 10 do livro)
    """
    projeto = DadosProjetoVISIA(
        nome_projeto="Projeto Inclusão Social Urbana - Nós do Centro",
        descricao="Programa de combate à vulnerabilidade social na região central de São Paulo",
        orgao_responsavel="Prefeitura de São Paulo",
        municipio="São Paulo",
        estado="SP",
        data_inicio="2006-01-01",
        data_fim="2009-12-31",
        investimento_total=75_000_000  # R$ 75 milhões total
    )
    
    # Dados Educacionais (do livro)
    projeto.educacional = DadosDimensaoEducacional(
        jovens_capacitados=4900,
        taxa_empregabilidade=65,
        investimento=20_000_000
    )
    
    # Dados Econômicos (do livro)
    projeto.economica = DadosDimensaoEconomica(
        microcreditos_concedidos=2500,
        valor_medio_credito=5000,
        investimento=15_000_000
    )
    
    # Dados Social-Ambiental (do livro)
    projeto.social_ambiental = DadosDimensaoSocialAmbiental(
        populacao_beneficiada=50000,
        taxa_melhoria_qualidade_vida=50,
        creditos_carbono_gerados=100000,
        impacto_economia_circular=20,
        investimento=30_000_000
    )
    
    # Dados Político-Público (do livro)
    projeto.politico_publica = DadosDimensaoPoliticoPublica(
        gestores_capacitados=300,
        transparencia_aumento=40,
        investimentos_captados=10_000_000,
        leis_regulamentacoes=5,
        investimento=10_000_000
    )
    
    return projeto


# ==============================================================================
# TESTE DO MOTOR
# ==============================================================================

if __name__ == "__main__":
    print("=" * 80)
    print("TESTE DO MOTOR VISIA")
    print("=" * 80)
    
    # Cria motor
    engine = VisiaEngine()
    print(f"\nMetodologia: {engine.metodologia}")
    print(f"Autor: {engine.autor}")
    print(f"ISBN: {engine.isbn}")
    
    # Cria projeto exemplo (Nós do Centro)
    projeto = criar_projeto_exemplo()
    print(f"\nProjeto: {projeto.nome_projeto}")
    
    # Executa análise
    resultado = engine.analisar_projeto(projeto)
    
    print("\n" + "-" * 80)
    print("RESULTADOS DA ANÁLISE VISIA")
    print("-" * 80)
    print(f"\n📚 Índice Educacional: {resultado.indice_educacional}%")
    print(f"💰 Índice Econômico: {resultado.indice_economico}%")
    print(f"🌱 Índice Social-Ambiental: {resultado.indice_social_ambiental}%")
    print(f"🏛️ Índice Político-Público: {resultado.indice_politico_publico}%")
    print(f"\n📊 IMPACTO TOTAL VISIA: {resultado.impacto_total}%")
    print(f"\n🏆 CLASSIFICAÇÃO: {resultado.classificacao}")
    print(f"📋 {resultado.recomendacao}")
    
    print(f"\n🔑 Hash do Projeto: {resultado.hash_resultado}")
    print(f"⏰ Timestamp: {resultado.timestamp}")
    
    if resultado.recomendacoes:
        print("\n" + "-" * 80)
        print("RECOMENDAÇÕES DE MELHORIA")
        print("-" * 80)
        for rec in resultado.recomendacoes:
            print(f"\n• {rec['dimensao']} [{rec['prioridade']}]")
            print(f"  Ação: {rec['acao']}")
            print(f"  Impacto esperado: {rec['impacto_estimado']}")

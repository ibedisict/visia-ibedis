"""
================================================================================
VISIA DATABASE - Sistema de Banco de Dados
================================================================================
Gerencia usuários, projetos, análises e auditoria.
Garante consistência e rastreabilidade das análises.
================================================================================
"""

import sqlite3
import hashlib
import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import secrets

# ==============================================================================
# ENUMS E CONSTANTES
# ==============================================================================

class TipoUsuario(Enum):
    ADMINISTRADOR = "administrador"
    USUARIO = "usuario"
    AUDITOR = "auditor"

class StatusProjeto(Enum):
    RASCUNHO = "rascunho"
    ANALISADO = "analisado"
    APROVADO = "aprovado"
    REPROVADO = "reprovado"
    ARQUIVADO = "arquivado"

class StatusAnalise(Enum):
    EM_ANDAMENTO = "em_andamento"
    CONCLUIDA = "concluida"
    REVISAO = "revisao"

# ==============================================================================
# ESTRUTURAS DE DADOS
# ==============================================================================

@dataclass
class Usuario:
    id: int = None
    nome: str = ""
    email: str = ""
    senha_hash: str = ""
    tipo: TipoUsuario = TipoUsuario.USUARIO
    ativo: bool = True
    api_key: str = ""
    data_criacao: str = ""
    ultimo_acesso: str = ""
    organizacao: str = ""
    cargo: str = ""

@dataclass
class Projeto:
    id: int = None
    nome: str = ""
    descricao: str = ""
    hash_documento: str = ""
    dados_json: str = ""
    usuario_id: int = None
    status: StatusProjeto = StatusProjeto.RASCUNHO
    data_criacao: str = ""
    data_atualizacao: str = ""
    arquivo_origem: str = ""
    versao: int = 1

@dataclass
class Analise:
    id: int = None
    projeto_id: int = None
    usuario_id: int = None
    resultado_json: str = ""
    impacto_total: float = 0
    classificacao: str = ""
    hash_resultado: str = ""
    status: StatusAnalise = StatusAnalise.CONCLUIDA
    data_analise: str = ""
    observacoes: str = ""
    versao: int = 1

@dataclass
class LogAuditoria:
    id: int = None
    usuario_id: int = None
    acao: str = ""
    entidade: str = ""
    entidade_id: int = None
    dados_anteriores: str = ""
    dados_novos: str = ""
    ip_address: str = ""
    data_hora: str = ""

@dataclass
class ConfiguracaoAPI:
    id: int = None
    nome: str = ""
    valor: str = ""
    descricao: str = ""
    data_atualizacao: str = ""

# ==============================================================================
# GERENCIADOR DE BANCO DE DADOS
# ==============================================================================

class VisiaDatabase:
    """
    Gerenciador principal do banco de dados VISIA.
    """
    
    def __init__(self, db_path: str = "visia.db"):
        """
        Inicializa conexão com o banco de dados.
        
        Args:
            db_path: Caminho para o arquivo do banco de dados
        """
        self.db_path = db_path
        self.conn = None
        self._conectar()
        self._criar_tabelas()
        self._criar_admin_padrao()
    
    def _conectar(self):
        """Estabelece conexão com o banco"""
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
    
    def _criar_tabelas(self):
        """Cria todas as tabelas necessárias"""
        cursor = self.conn.cursor()
        
        # Tabela de Usuários
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT UNIQUE NOT NULL,
                senha_hash TEXT NOT NULL,
                tipo TEXT NOT NULL DEFAULT 'usuario',
                ativo INTEGER DEFAULT 1,
                api_key TEXT UNIQUE,
                data_criacao TEXT NOT NULL,
                ultimo_acesso TEXT,
                organizacao TEXT,
                cargo TEXT
            )
        """)
        
        # Tabela de Projetos
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS projetos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                descricao TEXT,
                hash_documento TEXT,
                dados_json TEXT,
                usuario_id INTEGER,
                status TEXT DEFAULT 'rascunho',
                data_criacao TEXT NOT NULL,
                data_atualizacao TEXT,
                arquivo_origem TEXT,
                versao INTEGER DEFAULT 1,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
            )
        """)
        
        # Tabela de Análises
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS analises (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                projeto_id INTEGER NOT NULL,
                usuario_id INTEGER,
                resultado_json TEXT NOT NULL,
                impacto_total REAL,
                classificacao TEXT,
                hash_resultado TEXT,
                status TEXT DEFAULT 'concluida',
                data_analise TEXT NOT NULL,
                observacoes TEXT,
                versao INTEGER DEFAULT 1,
                FOREIGN KEY (projeto_id) REFERENCES projetos(id),
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
            )
        """)
        
        # Índice para busca rápida por hash (consistência)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_projeto_hash 
            ON projetos(hash_documento)
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_analise_hash 
            ON analises(hash_resultado)
        """)
        
        # Tabela de Log de Auditoria
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS log_auditoria (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER,
                acao TEXT NOT NULL,
                entidade TEXT NOT NULL,
                entidade_id INTEGER,
                dados_anteriores TEXT,
                dados_novos TEXT,
                ip_address TEXT,
                data_hora TEXT NOT NULL,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
            )
        """)
        
        # Tabela de Configurações API
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS configuracoes_api (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT UNIQUE NOT NULL,
                valor TEXT,
                descricao TEXT,
                data_atualizacao TEXT
            )
        """)
        
        # Tabela de Limites de Uso (Rate Limiting)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS uso_api (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER NOT NULL,
                api_key TEXT,
                endpoint TEXT,
                data_hora TEXT NOT NULL,
                ip_address TEXT,
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
            )
        """)
        
        # Tabela de Histórico de Alterações de Projetos
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS historico_projetos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                projeto_id INTEGER NOT NULL,
                campo_alterado TEXT NOT NULL,
                valor_anterior TEXT,
                valor_novo TEXT,
                usuario_id INTEGER,
                data_alteracao TEXT NOT NULL,
                FOREIGN KEY (projeto_id) REFERENCES projetos(id),
                FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
            )
        """)
        
        # Tabela de Base de Dados de Referência
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS dados_referencia (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                categoria TEXT NOT NULL,
                nome TEXT NOT NULL,
                valor REAL,
                unidade TEXT,
                fonte TEXT,
                ano_referencia INTEGER,
                data_atualizacao TEXT
            )
        """)
        
        self.conn.commit()
    
    def _criar_admin_padrao(self):
        """Cria usuário administrador padrão se não existir"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM usuarios WHERE tipo = 'administrador'")
        
        if cursor.fetchone()[0] == 0:
            self.criar_usuario(
                nome="Administrador VISIA",
                email="admin@visia.ibedis.org.br",
                senha="admin123",  # TROCAR EM PRODUÇÃO!
                tipo=TipoUsuario.ADMINISTRADOR,
                organizacao="IBEDIS",
                cargo="Administrador do Sistema"
            )
    
    # ==========================================================================
    # FUNÇÕES DE HASH E SEGURANÇA
    # ==========================================================================
    
    def _hash_senha(self, senha: str) -> str:
        """Gera hash seguro da senha"""
        return hashlib.sha256(senha.encode()).hexdigest()
    
    def _gerar_api_key(self) -> str:
        """Gera chave de API única"""
        return f"visia_{secrets.token_hex(32)}"
    
    def _gerar_hash_dados(self, dados: Dict) -> str:
        """Gera hash dos dados para verificação de consistência"""
        dados_json = json.dumps(dados, sort_keys=True)
        return hashlib.sha256(dados_json.encode()).hexdigest()[:16]
    
    # ==========================================================================
    # CRUD DE USUÁRIOS
    # ==========================================================================
    
    def criar_usuario(self, nome: str, email: str, senha: str, 
                     tipo: TipoUsuario = TipoUsuario.USUARIO,
                     organizacao: str = "", cargo: str = "") -> int:
        """Cria novo usuário"""
        cursor = self.conn.cursor()
        
        try:
            cursor.execute("""
                INSERT INTO usuarios (nome, email, senha_hash, tipo, api_key, 
                                      data_criacao, organizacao, cargo)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                nome, email, self._hash_senha(senha), tipo.value,
                self._gerar_api_key(), datetime.now().isoformat(),
                organizacao, cargo
            ))
            
            self.conn.commit()
            return cursor.lastrowid
        except sqlite3.IntegrityError:
            raise ValueError(f"Email {email} já cadastrado")
    
    def autenticar_usuario(self, email: str, senha: str) -> Optional[Dict]:
        """Autentica usuário por email e senha"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT * FROM usuarios 
            WHERE email = ? AND senha_hash = ? AND ativo = 1
        """, (email, self._hash_senha(senha)))
        
        row = cursor.fetchone()
        if row:
            # Atualiza último acesso
            cursor.execute("""
                UPDATE usuarios SET ultimo_acesso = ? WHERE id = ?
            """, (datetime.now().isoformat(), row['id']))
            self.conn.commit()
            
            return dict(row)
        return None
    
    def autenticar_api_key(self, api_key: str) -> Optional[Dict]:
        """Autentica usuário por API key"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT * FROM usuarios 
            WHERE api_key = ? AND ativo = 1
        """, (api_key,))
        
        row = cursor.fetchone()
        return dict(row) if row else None
    
    def listar_usuarios(self, tipo: TipoUsuario = None) -> List[Dict]:
        """Lista todos os usuários"""
        cursor = self.conn.cursor()
        
        if tipo:
            cursor.execute("SELECT * FROM usuarios WHERE tipo = ?", (tipo.value,))
        else:
            cursor.execute("SELECT * FROM usuarios")
        
        return [dict(row) for row in cursor.fetchall()]
    
    def obter_usuario(self, usuario_id: int) -> Optional[Dict]:
        """Obtém usuário por ID"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE id = ?", (usuario_id,))
        row = cursor.fetchone()
        return dict(row) if row else None
    
    def atualizar_usuario(self, usuario_id: int, **kwargs) -> bool:
        """Atualiza dados do usuário"""
        if not kwargs:
            return False
        
        campos = []
        valores = []
        
        for campo, valor in kwargs.items():
            if campo == 'senha':
                campos.append('senha_hash = ?')
                valores.append(self._hash_senha(valor))
            elif campo in ['nome', 'email', 'organizacao', 'cargo', 'ativo']:
                campos.append(f'{campo} = ?')
                valores.append(valor)
        
        if not campos:
            return False
        
        valores.append(usuario_id)
        cursor = self.conn.cursor()
        cursor.execute(f"""
            UPDATE usuarios SET {', '.join(campos)} WHERE id = ?
        """, valores)
        
        self.conn.commit()
        return cursor.rowcount > 0
    
    def regenerar_api_key(self, usuario_id: int) -> str:
        """Regenera API key do usuário"""
        nova_key = self._gerar_api_key()
        cursor = self.conn.cursor()
        cursor.execute("""
            UPDATE usuarios SET api_key = ? WHERE id = ?
        """, (nova_key, usuario_id))
        self.conn.commit()
        return nova_key
    
    # ==========================================================================
    # CRUD DE PROJETOS
    # ==========================================================================
    
    def criar_projeto(self, nome: str, dados: Dict, usuario_id: int,
                     descricao: str = "", arquivo_origem: str = "") -> int:
        """Cria novo projeto"""
        dados_json = json.dumps(dados, ensure_ascii=False)
        hash_documento = self._gerar_hash_dados(dados)
        
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO projetos (nome, descricao, hash_documento, dados_json,
                                  usuario_id, data_criacao, arquivo_origem)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            nome, descricao, hash_documento, dados_json,
            usuario_id, datetime.now().isoformat(), arquivo_origem
        ))
        
        self.conn.commit()
        return cursor.lastrowid
    
    def obter_projeto(self, projeto_id: int) -> Optional[Dict]:
        """Obtém projeto por ID"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM projetos WHERE id = ?", (projeto_id,))
        row = cursor.fetchone()
        
        if row:
            projeto = dict(row)
            projeto['dados'] = json.loads(projeto['dados_json']) if projeto['dados_json'] else {}
            return projeto
        return None
    
    def buscar_projeto_por_hash(self, hash_documento: str) -> Optional[Dict]:
        """
        Busca projeto por hash do documento.
        Garante que o mesmo documento sempre retorne a mesma análise.
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT * FROM projetos WHERE hash_documento = ?
        """, (hash_documento,))
        row = cursor.fetchone()
        
        if row:
            projeto = dict(row)
            projeto['dados'] = json.loads(projeto['dados_json']) if projeto['dados_json'] else {}
            return projeto
        return None
    
    def atualizar_projeto(self, projeto_id: int, dados: Dict = None, 
                         usuario_id: int = None, **kwargs) -> bool:
        """
        Atualiza projeto.
        Registra histórico de alterações para rastreabilidade.
        """
        cursor = self.conn.cursor()
        
        # Obtém dados atuais
        projeto_atual = self.obter_projeto(projeto_id)
        if not projeto_atual:
            return False
        
        campos_update = ['data_atualizacao = ?']
        valores = [datetime.now().isoformat()]
        
        # Atualiza dados JSON se fornecido
        if dados is not None:
            # Registra histórico de alterações
            dados_atuais = projeto_atual.get('dados', {})
            for campo, valor_novo in dados.items():
                valor_atual = dados_atuais.get(campo)
                if valor_atual != valor_novo:
                    self._registrar_alteracao(
                        projeto_id, campo, valor_atual, valor_novo, usuario_id
                    )
            
            dados_json = json.dumps(dados, ensure_ascii=False)
            hash_novo = self._gerar_hash_dados(dados)
            
            campos_update.extend(['dados_json = ?', 'hash_documento = ?'])
            valores.extend([dados_json, hash_novo])
        
        # Incrementa versão
        campos_update.append('versao = versao + 1')
        
        # Outros campos
        for campo, valor in kwargs.items():
            if campo in ['nome', 'descricao', 'status']:
                campos_update.append(f'{campo} = ?')
                valores.append(valor if campo != 'status' else valor.value if hasattr(valor, 'value') else valor)
        
        valores.append(projeto_id)
        
        cursor.execute(f"""
            UPDATE projetos SET {', '.join(campos_update)} WHERE id = ?
        """, valores)
        
        self.conn.commit()
        return cursor.rowcount > 0
    
    def _registrar_alteracao(self, projeto_id: int, campo: str, 
                            valor_anterior: Any, valor_novo: Any,
                            usuario_id: int = None):
        """Registra alteração no histórico"""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO historico_projetos 
            (projeto_id, campo_alterado, valor_anterior, valor_novo, 
             usuario_id, data_alteracao)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            projeto_id, campo, 
            json.dumps(valor_anterior, ensure_ascii=False) if valor_anterior else None,
            json.dumps(valor_novo, ensure_ascii=False) if valor_novo else None,
            usuario_id, datetime.now().isoformat()
        ))
        self.conn.commit()
    
    def listar_projetos(self, usuario_id: int = None, status: StatusProjeto = None,
                       limite: int = 100, offset: int = 0) -> List[Dict]:
        """Lista projetos com filtros"""
        cursor = self.conn.cursor()
        
        query = "SELECT * FROM projetos WHERE 1=1"
        params = []
        
        if usuario_id:
            query += " AND usuario_id = ?"
            params.append(usuario_id)
        
        if status:
            query += " AND status = ?"
            params.append(status.value)
        
        query += " ORDER BY data_criacao DESC LIMIT ? OFFSET ?"
        params.extend([limite, offset])
        
        cursor.execute(query, params)
        return [dict(row) for row in cursor.fetchall()]
    
    def obter_historico_projeto(self, projeto_id: int) -> List[Dict]:
        """Obtém histórico de alterações do projeto"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT h.*, u.nome as usuario_nome 
            FROM historico_projetos h
            LEFT JOIN usuarios u ON h.usuario_id = u.id
            WHERE h.projeto_id = ?
            ORDER BY h.data_alteracao DESC
        """, (projeto_id,))
        return [dict(row) for row in cursor.fetchall()]
    
    # ==========================================================================
    # CRUD DE ANÁLISES
    # ==========================================================================
    
    def criar_analise(self, projeto_id: int, resultado: Dict, 
                     usuario_id: int = None, observacoes: str = "") -> int:
        """Cria nova análise para um projeto"""
        resultado_json = json.dumps(resultado, ensure_ascii=False)
        hash_resultado = self._gerar_hash_dados(resultado)
        
        # Obtém versão atual
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT COALESCE(MAX(versao), 0) + 1 as nova_versao 
            FROM analises WHERE projeto_id = ?
        """, (projeto_id,))
        nova_versao = cursor.fetchone()['nova_versao']
        
        cursor.execute("""
            INSERT INTO analises (projeto_id, usuario_id, resultado_json,
                                  impacto_total, classificacao, hash_resultado,
                                  data_analise, observacoes, versao)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            projeto_id, usuario_id, resultado_json,
            resultado.get('impacto_total', 0),
            resultado.get('classificacao', ''),
            hash_resultado, datetime.now().isoformat(),
            observacoes, nova_versao
        ))
        
        # Atualiza status do projeto
        cursor.execute("""
            UPDATE projetos SET status = 'analisado', data_atualizacao = ?
            WHERE id = ?
        """, (datetime.now().isoformat(), projeto_id))
        
        self.conn.commit()
        return cursor.lastrowid
    
    def obter_analise(self, analise_id: int) -> Optional[Dict]:
        """Obtém análise por ID"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM analises WHERE id = ?", (analise_id,))
        row = cursor.fetchone()
        
        if row:
            analise = dict(row)
            analise['resultado'] = json.loads(analise['resultado_json']) if analise['resultado_json'] else {}
            return analise
        return None
    
    def obter_ultima_analise(self, projeto_id: int) -> Optional[Dict]:
        """Obtém última análise de um projeto"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT * FROM analises 
            WHERE projeto_id = ? 
            ORDER BY versao DESC LIMIT 1
        """, (projeto_id,))
        row = cursor.fetchone()
        
        if row:
            analise = dict(row)
            analise['resultado'] = json.loads(analise['resultado_json']) if analise['resultado_json'] else {}
            return analise
        return None
    
    def listar_analises_projeto(self, projeto_id: int) -> List[Dict]:
        """Lista todas as análises de um projeto (histórico)"""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT * FROM analises 
            WHERE projeto_id = ? 
            ORDER BY versao DESC
        """, (projeto_id,))
        
        analises = []
        for row in cursor.fetchall():
            analise = dict(row)
            analise['resultado'] = json.loads(analise['resultado_json']) if analise['resultado_json'] else {}
            analises.append(analise)
        
        return analises
    
    # ==========================================================================
    # GESTÃO DE USO E RATE LIMITING
    # ==========================================================================
    
    def registrar_uso_api(self, usuario_id: int, endpoint: str, 
                         api_key: str = None, ip_address: str = None):
        """Registra uso da API para rate limiting"""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO uso_api (usuario_id, api_key, endpoint, data_hora, ip_address)
            VALUES (?, ?, ?, ?, ?)
        """, (usuario_id, api_key, endpoint, datetime.now().isoformat(), ip_address))
        self.conn.commit()
    
    def verificar_limite_uso(self, usuario_id: int, limite_por_hora: int = 100) -> Tuple[bool, int]:
        """
        Verifica se usuário excedeu limite de uso.
        Returns: (dentro_do_limite, requisicoes_restantes)
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT COUNT(*) as total FROM uso_api 
            WHERE usuario_id = ? 
            AND datetime(data_hora) > datetime('now', '-1 hour')
        """, (usuario_id,))
        
        total = cursor.fetchone()['total']
        restantes = limite_por_hora - total
        
        return (total < limite_por_hora, max(0, restantes))
    
    def obter_estatisticas_uso(self, usuario_id: int = None) -> Dict:
        """Obtém estatísticas de uso da API"""
        cursor = self.conn.cursor()
        
        if usuario_id:
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_requisicoes,
                    COUNT(DISTINCT DATE(data_hora)) as dias_ativos,
                    endpoint,
                    COUNT(*) as count_endpoint
                FROM uso_api 
                WHERE usuario_id = ?
                GROUP BY endpoint
            """, (usuario_id,))
        else:
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_requisicoes,
                    COUNT(DISTINCT usuario_id) as usuarios_ativos,
                    COUNT(DISTINCT DATE(data_hora)) as dias,
                    endpoint,
                    COUNT(*) as count_endpoint
                FROM uso_api 
                GROUP BY endpoint
            """)
        
        return [dict(row) for row in cursor.fetchall()]
    
    # ==========================================================================
    # AUDITORIA
    # ==========================================================================
    
    def registrar_auditoria(self, usuario_id: int, acao: str, entidade: str,
                           entidade_id: int = None, dados_anteriores: Dict = None,
                           dados_novos: Dict = None, ip_address: str = None):
        """Registra ação no log de auditoria"""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO log_auditoria 
            (usuario_id, acao, entidade, entidade_id, dados_anteriores, 
             dados_novos, ip_address, data_hora)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            usuario_id, acao, entidade, entidade_id,
            json.dumps(dados_anteriores, ensure_ascii=False) if dados_anteriores else None,
            json.dumps(dados_novos, ensure_ascii=False) if dados_novos else None,
            ip_address, datetime.now().isoformat()
        ))
        self.conn.commit()
    
    def obter_logs_auditoria(self, usuario_id: int = None, entidade: str = None,
                            limite: int = 100) -> List[Dict]:
        """Obtém logs de auditoria"""
        cursor = self.conn.cursor()
        
        query = """
            SELECT l.*, u.nome as usuario_nome 
            FROM log_auditoria l
            LEFT JOIN usuarios u ON l.usuario_id = u.id
            WHERE 1=1
        """
        params = []
        
        if usuario_id:
            query += " AND l.usuario_id = ?"
            params.append(usuario_id)
        
        if entidade:
            query += " AND l.entidade = ?"
            params.append(entidade)
        
        query += " ORDER BY l.data_hora DESC LIMIT ?"
        params.append(limite)
        
        cursor.execute(query, params)
        return [dict(row) for row in cursor.fetchall()]
    
    # ==========================================================================
    # CONFIGURAÇÕES API
    # ==========================================================================
    
    def definir_configuracao(self, nome: str, valor: str, descricao: str = ""):
        """Define ou atualiza configuração"""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO configuracoes_api (nome, valor, descricao, data_atualizacao)
            VALUES (?, ?, ?, ?)
        """, (nome, valor, descricao, datetime.now().isoformat()))
        self.conn.commit()
    
    def obter_configuracao(self, nome: str) -> Optional[str]:
        """Obtém valor de configuração"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT valor FROM configuracoes_api WHERE nome = ?", (nome,))
        row = cursor.fetchone()
        return row['valor'] if row else None
    
    def listar_configuracoes(self) -> List[Dict]:
        """Lista todas as configurações"""
        cursor = self.conn.cursor()
        cursor.execute("SELECT * FROM configuracoes_api")
        return [dict(row) for row in cursor.fetchall()]
    
    # ==========================================================================
    # DADOS DE REFERÊNCIA
    # ==========================================================================
    
    def inserir_dado_referencia(self, categoria: str, nome: str, valor: float,
                               unidade: str = "", fonte: str = "", 
                               ano_referencia: int = None):
        """Insere dado de referência para cálculos"""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT OR REPLACE INTO dados_referencia 
            (categoria, nome, valor, unidade, fonte, ano_referencia, data_atualizacao)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            categoria, nome, valor, unidade, fonte, 
            ano_referencia or datetime.now().year,
            datetime.now().isoformat()
        ))
        self.conn.commit()
    
    def obter_dados_referencia(self, categoria: str = None) -> List[Dict]:
        """Obtém dados de referência"""
        cursor = self.conn.cursor()
        
        if categoria:
            cursor.execute("""
                SELECT * FROM dados_referencia WHERE categoria = ?
            """, (categoria,))
        else:
            cursor.execute("SELECT * FROM dados_referencia")
        
        return [dict(row) for row in cursor.fetchall()]
    
    # ==========================================================================
    # UTILITÁRIOS
    # ==========================================================================
    
    def fechar(self):
        """Fecha conexão com o banco"""
        if self.conn:
            self.conn.close()
    
    def backup(self, caminho_destino: str):
        """Cria backup do banco de dados"""
        import shutil
        shutil.copy2(self.db_path, caminho_destino)


# ==============================================================================
# TESTE DO BANCO DE DADOS
# ==============================================================================

if __name__ == "__main__":
    print("=" * 80)
    print("TESTE DO BANCO DE DADOS VISIA")
    print("=" * 80)
    
    # Cria banco de teste
    db = VisiaDatabase("visia_teste.db")
    
    print("\n✅ Banco de dados criado com sucesso!")
    
    # Testa criação de usuários
    print("\n--- TESTE DE USUÁRIOS ---")
    
    try:
        usuario_id = db.criar_usuario(
            nome="João Silva",
            email="joao@prefeitura.gov.br",
            senha="senha123",
            tipo=TipoUsuario.USUARIO,
            organizacao="Prefeitura de São Paulo",
            cargo="Analista de Projetos"
        )
        print(f"✅ Usuário criado: ID {usuario_id}")
    except ValueError as e:
        print(f"⚠️ {e}")
    
    # Testa autenticação
    usuario = db.autenticar_usuario("joao@prefeitura.gov.br", "senha123")
    if usuario:
        print(f"✅ Autenticação OK: {usuario['nome']}")
        print(f"   API Key: {usuario['api_key'][:20]}...")
    
    # Testa criação de projeto
    print("\n--- TESTE DE PROJETOS ---")
    
    dados_projeto = {
        "educacional": {"alunos": 5000, "melhoria": 20},
        "economico": {"empregos": 500, "renda": 3500},
        "social_ambiental": {"beneficiarios": 15000},
        "politico": {"gestores": 100}
    }
    
    projeto_id = db.criar_projeto(
        nome="Projeto Inclusão Digital",
        dados=dados_projeto,
        usuario_id=usuario_id,
        descricao="Capacitação em TI para jovens"
    )
    print(f"✅ Projeto criado: ID {projeto_id}")
    
    # Testa busca por hash
    projeto = db.obter_projeto(projeto_id)
    print(f"   Hash: {projeto['hash_documento']}")
    
    # Testa análise
    print("\n--- TESTE DE ANÁLISES ---")
    
    resultado = {
        "impacto_total": 45.5,
        "classificacao": "BOM",
        "indice_educacional": 37.5,
        "indice_economico": 52.3,
        "indice_social_ambiental": 42.1,
        "indice_politico_publico": 50.1
    }
    
    analise_id = db.criar_analise(
        projeto_id=projeto_id,
        resultado=resultado,
        usuario_id=usuario_id
    )
    print(f"✅ Análise criada: ID {analise_id}")
    
    # Lista usuários
    print("\n--- USUÁRIOS CADASTRADOS ---")
    for u in db.listar_usuarios():
        print(f"   • {u['nome']} ({u['tipo']}) - {u['email']}")
    
    # Limpa teste
    import os
    db.fechar()
    os.remove("visia_teste.db")
    print("\n✅ Testes concluídos com sucesso!")

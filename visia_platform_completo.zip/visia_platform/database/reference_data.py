"""
================================================================================
VISIA REFERENCE DATA - Base de Dados de Referência
================================================================================
Constantes, benchmarks e dados de referência para cálculos VISIA
Baseado no livro e em fontes oficiais brasileiras
================================================================================
"""

# ==============================================================================
# DADOS DE REFERÊNCIA - EDUCAÇÃO
# ==============================================================================

EDUCACAO = {
    # Custos médios por aluno (MEC/FNDE 2024)
    "custo_aluno_fundamental": 5500.00,  # R$/ano
    "custo_aluno_medio": 6200.00,  # R$/ano
    "custo_aluno_superior": 15000.00,  # R$/ano
    "custo_aluno_tecnico": 8500.00,  # R$/ano
    
    # Indicadores nacionais (INEP)
    "taxa_evasao_media_fundamental": 3.2,  # %
    "taxa_evasao_media_medio": 6.1,  # %
    "taxa_alfabetizacao_brasil": 93.0,  # %
    "ideb_medio_fundamental": 5.8,
    "ideb_medio_medio": 4.2,
    
    # Benchmarks VISIA (do livro)
    "impacto_educacional_excelente": 40,  # >= 40%
    "impacto_educacional_bom": 25,  # >= 25%
    "impacto_educacional_regular": 15,  # >= 15%
    
    # Multiplicadores de impacto
    "multiplicador_capacitacao_emprego": 0.65,  # 65% empregabilidade média
    "multiplicador_melhoria_renda": 1.35,  # 35% aumento renda com qualificação
}

# ==============================================================================
# DADOS DE REFERÊNCIA - ECONOMIA
# ==============================================================================

ECONOMIA = {
    # Salários médios (IBGE/PNAD 2024)
    "salario_minimo": 1412.00,  # R$/mês
    "salario_medio_brasil": 3200.00,  # R$/mês
    "renda_per_capita_media": 1750.00,  # R$/mês
    
    # Por região
    "salario_medio_sudeste": 3800.00,
    "salario_medio_sul": 3500.00,
    "salario_medio_centro_oeste": 3600.00,
    "salario_medio_nordeste": 2400.00,
    "salario_medio_norte": 2600.00,
    
    # Indicadores econômicos
    "pib_per_capita_brasil": 46154.00,  # R$/ano
    "taxa_desemprego_media": 7.8,  # %
    "taxa_informalidade": 38.5,  # %
    
    # Custos sociais evitados
    "custo_desempregado_ano": 15000.00,  # R$ - custo social
    "custo_assistencia_social_familia": 6000.00,  # R$/ano
    
    # Benchmarks VISIA (do livro)
    "impacto_economico_excelente": 50,  # >= 50%
    "impacto_economico_bom": 30,  # >= 30%
    "impacto_economico_regular": 15,  # >= 15%
    
    # Multiplicadores
    "multiplicador_emprego_indireto": 2.5,  # cada emprego direto gera 2.5 indiretos
    "multiplicador_renda_local": 1.8,  # efeito multiplicador na economia local
}

# ==============================================================================
# DADOS DE REFERÊNCIA - SOCIAL E AMBIENTAL
# ==============================================================================

SOCIAL_AMBIENTAL = {
    # Indicadores sociais (IBGE/Atlas Brasil)
    "idh_medio_brasil": 0.754,
    "indice_gini_brasil": 0.52,
    "taxa_pobreza": 31.6,  # % população
    "taxa_extrema_pobreza": 5.9,  # %
    
    # Saneamento e saúde
    "cobertura_agua_tratada": 84.1,  # %
    "cobertura_esgoto": 55.8,  # %
    "cobertura_coleta_lixo": 92.2,  # %
    
    # Custos de saúde evitados
    "custo_internacao_media": 2500.00,  # R$
    "custo_tratamento_doencas_saneamento": 800.00,  # R$/caso
    
    # Ambiental
    "valor_credito_carbono": 80.00,  # R$/tonelada CO2
    "custo_reflorestamento_hectare": 8000.00,  # R$/ha
    "sequestro_carbono_hectare_ano": 10.0,  # toneladas CO2/ha/ano
    
    # Economia circular
    "valor_reciclagem_tonelada": 350.00,  # R$/ton média
    "reducao_custo_aterro": 150.00,  # R$/ton
    
    # Benchmarks VISIA (do livro)
    "impacto_social_ambiental_excelente": 50,
    "impacto_social_ambiental_bom": 30,
    "impacto_social_ambiental_regular": 15,
    
    # Multiplicadores
    "multiplicador_qualidade_vida": 1.0,  # fator de conversão
    "multiplicador_impacto_ambiental": 1.2,
}

# ==============================================================================
# DADOS DE REFERÊNCIA - POLÍTICO-PÚBLICO
# ==============================================================================

POLITICO_PUBLICO = {
    # Indicadores de governança
    "indice_transparencia_medio": 5.2,  # escala 0-10
    "taxa_participacao_popular": 15.0,  # % população em conselhos
    
    # Custos de gestão
    "custo_capacitacao_servidor": 2500.00,  # R$/servidor
    "custo_medio_auditoria": 50000.00,  # R$
    
    # Captação de recursos
    "taxa_sucesso_captacao_federal": 35.0,  # %
    "taxa_sucesso_captacao_internacional": 20.0,  # %
    
    # Benchmarks VISIA (do livro)
    "impacto_politico_excelente": 40,
    "impacto_politico_bom": 25,
    "impacto_politico_regular": 15,
    
    # Multiplicadores
    "multiplicador_gestores_populacao": 2000,  # 1 gestor impacta ~2000 pessoas
    "multiplicador_transparencia": 1.5,
}

# ==============================================================================
# CLASSIFICAÇÃO VISIA - LIMIARES OFICIAIS DO LIVRO
# ==============================================================================

CLASSIFICACAO_VISIA = {
    "EXCELENTE": {
        "limiar_minimo": 50.0,
        "cor": "#28A745",
        "recomendacao": "APROVADO - Projeto com alto impacto positivo. Recomenda-se expansão e replicação.",
        "selo": "SELO VISIA OURO"
    },
    "BOM": {
        "limiar_minimo": 30.0,
        "cor": "#2E86AB",
        "recomendacao": "APROVADO COM RESSALVAS - Projeto com bom impacto. Monitorar indicadores.",
        "selo": "SELO VISIA PRATA"
    },
    "REGULAR": {
        "limiar_minimo": 15.0,
        "cor": "#FFC107",
        "recomendacao": "APROVADO COM AJUSTES - Implementar melhorias nas dimensões deficitárias.",
        "selo": "SELO VISIA BRONZE"
    },
    "INSUFICIENTE": {
        "limiar_minimo": 0.0,
        "cor": "#DC3545",
        "recomendacao": "NÃO RECOMENDADO - Projeto requer reformulação significativa.",
        "selo": None
    }
}

# ==============================================================================
# FÓRMULAS VISIA - REFERÊNCIA DO LIVRO
# ==============================================================================

FORMULAS_VISIA = {
    "educacional": {
        "principal": "I_edu = (Alunos × Melhoria%) / Investimento × 100",
        "alternativa": "I_edu = (Jovens × Empregabilidade%) / Investimento × 100",
        "variaveis": [
            "alunos_impactados",
            "melhoria_desempenho",
            "jovens_capacitados", 
            "taxa_empregabilidade",
            "investimento"
        ],
        "capitulo_livro": "4.1"
    },
    "economico": {
        "principal": "I_eco = (Empregos × Renda_média) / Investimento × 100",
        "alternativa": "I_eco = (Microcréditos × Valor_médio) / Investimento × 100",
        "variaveis": [
            "empregos_gerados",
            "renda_media",
            "microcreditos_concedidos",
            "valor_medio_credito",
            "investimento"
        ],
        "capitulo_livro": "4.2"
    },
    "social_ambiental": {
        "principal": "I_soc = [(Pop × Melhoria%) + (Carbono × Circular%)] / Invest × 100",
        "alternativa": "I_soc = [(Benef × Melhoria%) + (Proj_sust × F_sust)] / Invest × 100",
        "variaveis": [
            "populacao_beneficiada",
            "taxa_melhoria_qualidade_vida",
            "creditos_carbono_gerados",
            "impacto_economia_circular",
            "projetos_sustentaveis",
            "investimento"
        ],
        "capitulo_livro": "4.3"
    },
    "politico_publico": {
        "principal": "I_pol = [(Gestores × Pop) + (Políticas × Captado)] / Invest × 100",
        "variaveis": [
            "gestores_capacitados",
            "populacao_impactada",
            "transparencia_aumento",
            "investimentos_captados",
            "numero_politicas_criadas",
            "investimento"
        ],
        "capitulo_livro": "4.4"
    },
    "impacto_total": {
        "formula": "I_total = (I_edu + I_eco + I_soc + I_pol) / 4",
        "descricao": "Média aritmética simples das 4 dimensões",
        "capitulo_livro": "9.2"
    }
}

# ==============================================================================
# SETORES DE APLICAÇÃO
# ==============================================================================

SETORES = {
    "educacao": {
        "nome": "Educação",
        "indicadores_chave": ["alunos_beneficiados", "melhoria_ideb", "taxa_evasao"],
        "peso_educacional": 0.4,
        "peso_economico": 0.2,
        "peso_social": 0.3,
        "peso_politico": 0.1
    },
    "saude": {
        "nome": "Saúde",
        "indicadores_chave": ["pacientes_atendidos", "reducao_internacoes", "cobertura_vacinal"],
        "peso_educacional": 0.1,
        "peso_economico": 0.2,
        "peso_social": 0.5,
        "peso_politico": 0.2
    },
    "infraestrutura": {
        "nome": "Infraestrutura",
        "indicadores_chave": ["km_construidos", "populacao_atendida", "empregos_obra"],
        "peso_educacional": 0.1,
        "peso_economico": 0.4,
        "peso_social": 0.3,
        "peso_politico": 0.2
    },
    "meio_ambiente": {
        "nome": "Meio Ambiente",
        "indicadores_chave": ["area_preservada", "emissoes_evitadas", "reciclagem"],
        "peso_educacional": 0.2,
        "peso_economico": 0.2,
        "peso_social": 0.4,
        "peso_politico": 0.2
    },
    "assistencia_social": {
        "nome": "Assistência Social",
        "indicadores_chave": ["familias_atendidas", "reducao_pobreza", "inclusao_produtiva"],
        "peso_educacional": 0.2,
        "peso_economico": 0.3,
        "peso_social": 0.4,
        "peso_politico": 0.1
    },
    "seguranca": {
        "nome": "Segurança Pública",
        "indicadores_chave": ["reducao_criminalidade", "equipamentos_instalados", "agentes_treinados"],
        "peso_educacional": 0.1,
        "peso_economico": 0.2,
        "peso_social": 0.4,
        "peso_politico": 0.3
    },
    "cultura_esporte": {
        "nome": "Cultura e Esporte",
        "indicadores_chave": ["eventos_realizados", "participantes", "espacos_criados"],
        "peso_educacional": 0.3,
        "peso_economico": 0.2,
        "peso_social": 0.4,
        "peso_politico": 0.1
    },
    "tecnologia": {
        "nome": "Tecnologia e Inovação",
        "indicadores_chave": ["pessoas_capacitadas", "sistemas_implantados", "economia_gerada"],
        "peso_educacional": 0.3,
        "peso_economico": 0.3,
        "peso_social": 0.2,
        "peso_politico": 0.2
    }
}

# ==============================================================================
# COMPARATIVO VISIA vs OUTRAS METODOLOGIAS
# ==============================================================================

COMPARATIVO_METODOLOGIAS = {
    "VISIA": {
        "nome_completo": "Valoração Integrada de Sustentabilidade e Impacto Aplicado",
        "origem": "Brasil",
        "autor": "Wemerson Marinho",
        "ano": 2024,
        "foco": "Políticas Públicas Brasileiras",
        "dimensoes": 4,
        "aplicabilidade_brasil": "Alta",
        "facilidade_implementacao": "Alta",
        "integracao_multidimensional": True,
        "base_evidencias": True,
        "diferenciais": [
            "Desenvolvida especificamente para o contexto brasileiro",
            "Integra 4 dimensões em análise única",
            "Fórmulas padronizadas e replicáveis",
            "Foco em transparência e governança",
            "Adaptável a diferentes setores públicos"
        ]
    },
    "SROI": {
        "nome_completo": "Social Return on Investment",
        "origem": "Reino Unido",
        "ano": 2000,
        "foco": "Terceiro Setor / ONGs",
        "dimensoes": 1,
        "aplicabilidade_brasil": "Baixa",
        "facilidade_implementacao": "Média",
        "integracao_multidimensional": False,
        "base_evidencias": True,
        "limitacoes": [
            "Foco exclusivo em retorno financeiro",
            "Não considera dimensão política",
            "Complexidade na monetização de impactos",
            "Desenvolvido para contexto europeu"
        ]
    },
    "IDH": {
        "nome_completo": "Índice de Desenvolvimento Humano",
        "origem": "ONU/PNUD",
        "ano": 1990,
        "foco": "Desenvolvimento de Países",
        "dimensoes": 3,
        "aplicabilidade_brasil": "Média",
        "facilidade_implementacao": "Alta",
        "integracao_multidimensional": True,
        "base_evidencias": True,
        "limitacoes": [
            "Não avalia projetos específicos",
            "Indicadores muito agregados",
            "Não considera governança local",
            "Atualização lenta (anual)"
        ]
    }
}

# ==============================================================================
# ODS - OBJETIVOS DE DESENVOLVIMENTO SUSTENTÁVEL
# ==============================================================================

ODS_MAPEAMENTO = {
    1: {"nome": "Erradicação da Pobreza", "dimensoes_visia": ["social_ambiental", "economico"]},
    2: {"nome": "Fome Zero", "dimensoes_visia": ["social_ambiental"]},
    3: {"nome": "Saúde e Bem-Estar", "dimensoes_visia": ["social_ambiental"]},
    4: {"nome": "Educação de Qualidade", "dimensoes_visia": ["educacional"]},
    5: {"nome": "Igualdade de Gênero", "dimensoes_visia": ["social_ambiental", "politico"]},
    6: {"nome": "Água Potável e Saneamento", "dimensoes_visia": ["social_ambiental"]},
    7: {"nome": "Energia Limpa", "dimensoes_visia": ["social_ambiental", "economico"]},
    8: {"nome": "Trabalho Decente", "dimensoes_visia": ["economico"]},
    9: {"nome": "Indústria e Inovação", "dimensoes_visia": ["economico", "educacional"]},
    10: {"nome": "Redução das Desigualdades", "dimensoes_visia": ["social_ambiental", "economico"]},
    11: {"nome": "Cidades Sustentáveis", "dimensoes_visia": ["social_ambiental", "politico"]},
    12: {"nome": "Consumo Responsável", "dimensoes_visia": ["social_ambiental"]},
    13: {"nome": "Ação Climática", "dimensoes_visia": ["social_ambiental"]},
    14: {"nome": "Vida na Água", "dimensoes_visia": ["social_ambiental"]},
    15: {"nome": "Vida Terrestre", "dimensoes_visia": ["social_ambiental"]},
    16: {"nome": "Paz e Justiça", "dimensoes_visia": ["politico", "social_ambiental"]},
    17: {"nome": "Parcerias", "dimensoes_visia": ["politico"]}
}

# ==============================================================================
# FUNÇÃO PARA CARREGAR DADOS NO BANCO
# ==============================================================================

def carregar_dados_referencia(db):
    """Carrega todos os dados de referência no banco de dados"""
    
    # Educação
    for nome, valor in EDUCACAO.items():
        if isinstance(valor, (int, float)):
            db.inserir_dado_referencia(
                categoria="educacao",
                nome=nome,
                valor=valor,
                fonte="MEC/INEP",
                ano_referencia=2024
            )
    
    # Economia
    for nome, valor in ECONOMIA.items():
        if isinstance(valor, (int, float)):
            db.inserir_dado_referencia(
                categoria="economia",
                nome=nome,
                valor=valor,
                fonte="IBGE/PNAD",
                ano_referencia=2024
            )
    
    # Social/Ambiental
    for nome, valor in SOCIAL_AMBIENTAL.items():
        if isinstance(valor, (int, float)):
            db.inserir_dado_referencia(
                categoria="social_ambiental",
                nome=nome,
                valor=valor,
                fonte="IBGE/Atlas Brasil",
                ano_referencia=2024
            )
    
    # Político
    for nome, valor in POLITICO_PUBLICO.items():
        if isinstance(valor, (int, float)):
            db.inserir_dado_referencia(
                categoria="politico_publico",
                nome=nome,
                valor=valor,
                fonte="CGU/TCU",
                ano_referencia=2024
            )
    
    print("✅ Dados de referência carregados com sucesso!")


if __name__ == "__main__":
    print("=" * 60)
    print("BASE DE DADOS DE REFERÊNCIA VISIA")
    print("=" * 60)
    
    print("\n📚 EDUCAÇÃO:")
    for k, v in list(EDUCACAO.items())[:5]:
        print(f"  • {k}: {v}")
    
    print("\n💰 ECONOMIA:")
    for k, v in list(ECONOMIA.items())[:5]:
        print(f"  • {k}: {v}")
    
    print("\n🌱 SOCIAL/AMBIENTAL:")
    for k, v in list(SOCIAL_AMBIENTAL.items())[:5]:
        print(f"  • {k}: {v}")
    
    print("\n🏛️ POLÍTICO-PÚBLICO:")
    for k, v in list(POLITICO_PUBLICO.items())[:5]:
        print(f"  • {k}: {v}")
    
    print("\n📊 CLASSIFICAÇÃO VISIA:")
    for classe, dados in CLASSIFICACAO_VISIA.items():
        print(f"  • {classe}: >= {dados['limiar_minimo']}%")

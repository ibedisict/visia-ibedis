"""
================================================================================
VISIA AI EXTRACTOR - Motor de IA para Extração de Dados
================================================================================
Extrai automaticamente dados de projetos de arquivos PDF e Word
para alimentar a análise VISIA.
================================================================================
"""

import re
import json
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
import hashlib
from datetime import datetime

# Importação condicional de bibliotecas de processamento
try:
    import PyPDF2
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

try:
    from docx import Document
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False

# ==============================================================================
# ESTRUTURAS DE DADOS PARA EXTRAÇÃO
# ==============================================================================

@dataclass
class DadosExtraidos:
    """Dados extraídos de um documento"""
    # Identificação
    nome_projeto: str = ""
    descricao: str = ""
    orgao_responsavel: str = ""
    municipio: str = ""
    estado: str = ""
    
    # Valores numéricos extraídos
    investimento_total: float = 0
    beneficiarios: int = 0
    empregos: int = 0
    duracao_meses: int = 0
    
    # Indicadores específicos
    indicadores_encontrados: Dict = None
    
    # Texto completo para análise
    texto_completo: str = ""
    
    # Metadados
    arquivo_origem: str = ""
    hash_documento: str = ""
    confianca_extracao: float = 0
    campos_manuais_necessarios: List[str] = None
    
    def __post_init__(self):
        if self.indicadores_encontrados is None:
            self.indicadores_encontrados = {}
        if self.campos_manuais_necessarios is None:
            self.campos_manuais_necessarios = []


# ==============================================================================
# PADRÕES DE EXTRAÇÃO (REGEX)
# ==============================================================================

class PadroesExtracao:
    """Padrões regex para extração de dados de projetos públicos"""
    
    # Valores monetários
    VALOR_REAIS = [
        r'R\$\s*([\d.,]+)\s*(mil|milh[õo]es?|bilh[õo]es?)?',
        r'(\d{1,3}(?:\.\d{3})*(?:,\d{2})?)\s*reais',
        r'investimento(?:\s+(?:total|de))?\s*(?:de)?\s*R\$\s*([\d.,]+)',
        r'or[çc]amento\s*(?:de)?\s*R\$\s*([\d.,]+)',
        r'custo\s*(?:total)?\s*(?:de)?\s*R\$\s*([\d.,]+)',
        r'valor\s*(?:total)?\s*(?:de)?\s*R\$\s*([\d.,]+)',
    ]
    
    # Beneficiários/População
    BENEFICIARIOS = [
        r'(\d{1,3}(?:\.\d{3})*)\s*(?:pessoas?|benefici[aá]rios?|cidad[aã]os?|habitantes?)',
        r'atender[aá]?\s*(\d{1,3}(?:\.\d{3})*)',
        r'beneficiar[aá]?\s*(\d{1,3}(?:\.\d{3})*)',
        r'popula[çc][aã]o\s*(?:de)?\s*(\d{1,3}(?:\.\d{3})*)',
        r'(\d{1,3}(?:\.\d{3})*)\s*(?:fam[ií]lias?|domic[ií]lios?)',
        r'(\d{1,3}(?:\.\d{3})*)\s*alunos?',
        r'(\d{1,3}(?:\.\d{3})*)\s*jovens?',
        r'(\d{1,3}(?:\.\d{3})*)\s*estudantes?',
    ]
    
    # Empregos
    EMPREGOS = [
        r'(\d{1,3}(?:\.\d{3})*)\s*(?:novos?\s*)?empregos?',
        r'gera[çc][aã]o\s*de\s*(\d{1,3}(?:\.\d{3})*)\s*(?:novos?\s*)?empregos?',
        r'(\d{1,3}(?:\.\d{3})*)\s*postos?\s*de\s*trabalho',
        r'empregar\s*(\d{1,3}(?:\.\d{3})*)',
        r'(\d{1,3}(?:\.\d{3})*)\s*vagas?',
    ]
    
    # Localização
    MUNICIPIO = [
        r'munic[ií]pio\s*(?:de)?\s*([A-ZÀ-Ú][a-zà-ú]+(?:\s+[A-ZÀ-Ú][a-zà-ú]+)*)',
        r'cidade\s*(?:de)?\s*([A-ZÀ-Ú][a-zà-ú]+(?:\s+[A-ZÀ-Ú][a-zà-ú]+)*)',
        r'em\s*([A-ZÀ-Ú][a-zà-ú]+(?:\s+[A-ZÀ-Ú][a-zà-ú]+)*)\s*[-–]\s*([A-Z]{2})',
    ]
    
    ESTADO = [
        r'estado\s*(?:de|do|da)?\s*([A-ZÀ-Ú][a-zà-ú]+(?:\s+[A-ZÀ-Ú][a-zà-ú]+)*)',
        r'\b([A-Z]{2})\b',  # Sigla de estado
    ]
    
    # Órgão responsável
    ORGAO = [
        r'(?:prefeitura|governo|secretaria|minist[ée]rio|autarquia)\s*(?:municipal|estadual|federal)?\s*(?:de|do|da)?\s*([A-ZÀ-Ú][a-zà-ú\s]+)',
        r'[óo]rg[aã]o\s*(?:executor|respons[aá]vel)?\s*:\s*([^\n]+)',
        r'proponente\s*:\s*([^\n]+)',
    ]
    
    # Indicadores educacionais
    EDUCACIONAL = [
        r'(\d{1,3}(?:\.\d{3})*)\s*alunos?\s*(?:beneficiados?|atendidos?|capacitados?)',
        r'melhoria\s*(?:de)?\s*(\d+(?:,\d+)?)\s*%?\s*(?:no\s*)?(?:desempenho|aprendizado)',
        r'redu[çc][aã]o\s*(?:de)?\s*(\d+(?:,\d+)?)\s*%?\s*(?:na\s*)?evas[aã]o',
        r'taxa\s*de\s*empregabilidade\s*(?:de)?\s*(\d+(?:,\d+)?)\s*%',
        r'(\d{1,3}(?:\.\d{3})*)\s*(?:jovens?|pessoas?)\s*capacitad[ao]s?',
    ]
    
    # Indicadores econômicos
    ECONOMICO = [
        r'renda\s*m[ée]dia\s*(?:de)?\s*R\$\s*([\d.,]+)',
        r'sal[aá]rio\s*m[ée]dio\s*(?:de)?\s*R\$\s*([\d.,]+)',
        r'(\d{1,3}(?:\.\d{3})*)\s*microcr[ée]ditos?',
        r'valor\s*m[ée]dio\s*(?:do\s*)?cr[ée]dito\s*(?:de)?\s*R\$\s*([\d.,]+)',
        r'aumento\s*(?:de)?\s*(\d+(?:,\d+)?)\s*%?\s*(?:na\s*)?(?:renda|arrecada[çc][aã]o)',
    ]
    
    # Indicadores social-ambiental
    SOCIAL_AMBIENTAL = [
        r'(\d{1,3}(?:\.\d{3})*)\s*(?:hectares?|ha)\s*(?:recuperados?|preservados?|reflorestados?)',
        r'(\d{1,3}(?:\.\d{3})*)\s*(?:toneladas?|t)\s*(?:de\s*)?(?:CO2|carbono)',
        r'redu[çc][aã]o\s*(?:de)?\s*(\d+(?:,\d+)?)\s*%?\s*(?:na\s*)?(?:emiss[aã]o|polui[çc][aã]o)',
        r'melhoria\s*(?:de)?\s*(\d+(?:,\d+)?)\s*%?\s*(?:na\s*)?qualidade\s*de\s*vida',
        r'(\d{1,3}(?:\.\d{3})*)\s*(?:cr[ée]ditos?\s*de\s*)?carbono',
    ]
    
    # Indicadores político-público
    POLITICO = [
        r'(\d{1,3}(?:\.\d{3})*)\s*gestores?\s*(?:capacitados?|treinados?)',
        r'(\d{1,3}(?:\.\d{3})*)\s*servidores?\s*(?:capacitados?|treinados?)',
        r'aumento\s*(?:de)?\s*(\d+(?:,\d+)?)\s*%?\s*(?:na\s*)?transpar[eê]ncia',
        r'capta[çc][aã]o\s*(?:de)?\s*R\$\s*([\d.,]+)\s*(?:em\s*)?investimentos?',
        r'(\d+)\s*(?:novas?\s*)?(?:leis?|regulamenta[çc][oõ]es?|pol[ií]ticas?)\s*(?:criadas?|implementadas?)',
    ]
    
    # Duração do projeto
    DURACAO = [
        r'dura[çc][aã]o\s*(?:de)?\s*(\d+)\s*(?:meses?|anos?)',
        r'per[ií]odo\s*(?:de)?\s*(\d+)\s*(?:meses?|anos?)',
        r'prazo\s*(?:de)?\s*(\d+)\s*(?:meses?|anos?)',
        r'execu[çc][aã]o\s*(?:em)?\s*(\d+)\s*(?:meses?|anos?)',
    ]


# ==============================================================================
# MOTOR DE EXTRAÇÃO
# ==============================================================================

class VisiaAIExtractor:
    """
    Motor de IA para extração de dados de documentos.
    Analisa PDFs e documentos Word para identificar informações
    relevantes para a análise VISIA.
    """
    
    def __init__(self, api_key: str = None):
        """
        Inicializa o extrator.
        
        Args:
            api_key: Chave de API para serviços de IA (opcional)
        """
        self.api_key = api_key
        self.padroes = PadroesExtracao()
        
    # ==========================================================================
    # LEITURA DE ARQUIVOS
    # ==========================================================================
    
    def ler_pdf(self, caminho_arquivo: str) -> str:
        """Lê conteúdo de arquivo PDF"""
        if not PDF_AVAILABLE:
            raise ImportError("PyPDF2 não está instalado. Execute: pip install PyPDF2")
        
        texto = ""
        with open(caminho_arquivo, 'rb') as arquivo:
            leitor = PyPDF2.PdfReader(arquivo)
            for pagina in leitor.pages:
                texto += pagina.extract_text() + "\n"
        return texto
    
    def ler_docx(self, caminho_arquivo: str) -> str:
        """Lê conteúdo de arquivo Word (.docx)"""
        if not DOCX_AVAILABLE:
            raise ImportError("python-docx não está instalado. Execute: pip install python-docx")
        
        doc = Document(caminho_arquivo)
        texto = "\n".join([paragrafo.text for paragrafo in doc.paragraphs])
        
        # Também extrai texto de tabelas
        for tabela in doc.tables:
            for linha in tabela.rows:
                texto += "\n" + " | ".join([celula.text for celula in linha.cells])
        
        return texto
    
    def ler_arquivo(self, caminho_arquivo: str) -> str:
        """Lê arquivo baseado na extensão"""
        caminho_lower = caminho_arquivo.lower()
        
        if caminho_lower.endswith('.pdf'):
            return self.ler_pdf(caminho_arquivo)
        elif caminho_lower.endswith('.docx'):
            return self.ler_docx(caminho_arquivo)
        elif caminho_lower.endswith('.doc'):
            raise ValueError("Formato .doc não suportado. Converta para .docx")
        elif caminho_lower.endswith('.txt'):
            with open(caminho_arquivo, 'r', encoding='utf-8') as f:
                return f.read()
        else:
            raise ValueError(f"Formato de arquivo não suportado: {caminho_arquivo}")
    
    # ==========================================================================
    # FUNÇÕES DE EXTRAÇÃO
    # ==========================================================================
    
    def _converter_valor_monetario(self, valor: str, unidade: str = None) -> float:
        """Converte string de valor monetário para float"""
        # Remove pontos de milhar e troca vírgula por ponto
        valor_limpo = valor.replace('.', '').replace(',', '.')
        
        try:
            numero = float(valor_limpo)
        except ValueError:
            return 0
        
        # Aplica multiplicador baseado na unidade
        if unidade:
            unidade_lower = unidade.lower()
            if 'milh' in unidade_lower:
                numero *= 1_000_000
            elif 'bilh' in unidade_lower:
                numero *= 1_000_000_000
            elif 'mil' in unidade_lower:
                numero *= 1_000
        
        return numero
    
    def _converter_numero(self, valor: str) -> int:
        """Converte string de número para inteiro"""
        valor_limpo = valor.replace('.', '').replace(',', '')
        try:
            return int(valor_limpo)
        except ValueError:
            return 0
    
    def _extrair_primeiro_match(self, texto: str, padroes: List[str]) -> Optional[str]:
        """Extrai primeiro match de uma lista de padrões"""
        for padrao in padroes:
            match = re.search(padrao, texto, re.IGNORECASE)
            if match:
                return match.group(1) if match.groups() else match.group(0)
        return None
    
    def _extrair_todos_matches(self, texto: str, padroes: List[str]) -> List[Tuple]:
        """Extrai todos os matches de uma lista de padrões"""
        resultados = []
        for padrao in padroes:
            matches = re.findall(padrao, texto, re.IGNORECASE)
            resultados.extend(matches)
        return resultados
    
    # ==========================================================================
    # EXTRAÇÃO PRINCIPAL
    # ==========================================================================
    
    def extrair_dados(self, texto: str, arquivo_origem: str = "") -> DadosExtraidos:
        """
        Extrai dados de um texto para análise VISIA.
        
        Args:
            texto: Texto do documento
            arquivo_origem: Nome do arquivo de origem
            
        Returns:
            DadosExtraidos com os dados encontrados
        """
        dados = DadosExtraidos()
        dados.texto_completo = texto
        dados.arquivo_origem = arquivo_origem
        dados.hash_documento = hashlib.sha256(texto.encode()).hexdigest()[:16]
        
        campos_encontrados = 0
        total_campos = 15  # Número esperado de campos
        
        # Extrai investimento total
        valores = self._extrair_todos_matches(texto, self.padroes.VALOR_REAIS)
        if valores:
            # Pega o maior valor encontrado (geralmente o total)
            valores_convertidos = []
            for v in valores:
                if isinstance(v, tuple):
                    valor_conv = self._converter_valor_monetario(v[0], v[1] if len(v) > 1 else None)
                else:
                    valor_conv = self._converter_valor_monetario(v)
                valores_convertidos.append(valor_conv)
            
            dados.investimento_total = max(valores_convertidos) if valores_convertidos else 0
            if dados.investimento_total > 0:
                campos_encontrados += 1
        
        # Extrai beneficiários
        beneficiarios = self._extrair_todos_matches(texto, self.padroes.BENEFICIARIOS)
        if beneficiarios:
            valores_benef = [self._converter_numero(b if isinstance(b, str) else b[0]) for b in beneficiarios]
            dados.beneficiarios = max(valores_benef) if valores_benef else 0
            if dados.beneficiarios > 0:
                campos_encontrados += 1
        
        # Extrai empregos
        empregos = self._extrair_todos_matches(texto, self.padroes.EMPREGOS)
        if empregos:
            valores_emp = [self._converter_numero(e if isinstance(e, str) else e[0]) for e in empregos]
            dados.empregos = max(valores_emp) if valores_emp else 0
            if dados.empregos > 0:
                campos_encontrados += 1
        
        # Extrai município
        municipio = self._extrair_primeiro_match(texto, self.padroes.MUNICIPIO)
        if municipio:
            dados.municipio = municipio.strip()
            campos_encontrados += 1
        
        # Extrai estado
        estado = self._extrair_primeiro_match(texto, self.padroes.ESTADO)
        if estado:
            dados.estado = estado.strip()
            campos_encontrados += 1
        
        # Extrai órgão responsável
        orgao = self._extrair_primeiro_match(texto, self.padroes.ORGAO)
        if orgao:
            dados.orgao_responsavel = orgao.strip()
            campos_encontrados += 1
        
        # Extrai duração
        duracao = self._extrair_primeiro_match(texto, self.padroes.DURACAO)
        if duracao:
            try:
                dados.duracao_meses = int(duracao)
                if 'ano' in texto.lower():
                    dados.duracao_meses *= 12
                campos_encontrados += 1
            except:
                pass
        
        # Extrai nome do projeto (primeiras linhas geralmente)
        linhas = texto.strip().split('\n')
        for linha in linhas[:10]:
            linha_limpa = linha.strip()
            if len(linha_limpa) > 10 and len(linha_limpa) < 200:
                if any(palavra in linha_limpa.lower() for palavra in ['projeto', 'programa', 'plano']):
                    dados.nome_projeto = linha_limpa
                    campos_encontrados += 1
                    break
        
        # ==================================================================
        # EXTRAÇÃO DE INDICADORES ESPECÍFICOS VISIA
        # ==================================================================
        
        indicadores = {}
        
        # Indicadores Educacionais
        edu_matches = self._extrair_todos_matches(texto, self.padroes.EDUCACIONAL)
        if edu_matches:
            indicadores['educacional'] = {
                'alunos_beneficiados': 0,
                'melhoria_desempenho': 0,
                'reducao_evasao': 0,
                'taxa_empregabilidade': 0,
                'jovens_capacitados': 0
            }
            for match in edu_matches:
                valor = self._converter_numero(match if isinstance(match, str) else match[0])
                # Determina qual indicador baseado no contexto
                if valor > 100:  # Provavelmente quantidade de pessoas
                    indicadores['educacional']['alunos_beneficiados'] = max(
                        indicadores['educacional']['alunos_beneficiados'], valor
                    )
                else:  # Provavelmente percentual
                    indicadores['educacional']['melhoria_desempenho'] = max(
                        indicadores['educacional']['melhoria_desempenho'], valor
                    )
            campos_encontrados += 1
        
        # Indicadores Econômicos
        eco_matches = self._extrair_todos_matches(texto, self.padroes.ECONOMICO)
        if eco_matches:
            indicadores['economico'] = {
                'renda_media': 0,
                'microcreditos': 0,
                'valor_credito': 0
            }
            for match in eco_matches:
                if isinstance(match, tuple):
                    valor = self._converter_valor_monetario(match[0])
                else:
                    valor = self._converter_valor_monetario(match) if ',' in str(match) or '.' in str(match) else self._converter_numero(match)
                
                if valor > 10000:  # Provavelmente renda ou valor de crédito
                    indicadores['economico']['renda_media'] = max(indicadores['economico']['renda_media'], valor)
                elif valor > 100:
                    indicadores['economico']['microcreditos'] = max(indicadores['economico']['microcreditos'], int(valor))
            campos_encontrados += 1
        
        # Indicadores Social-Ambiental
        soc_matches = self._extrair_todos_matches(texto, self.padroes.SOCIAL_AMBIENTAL)
        if soc_matches:
            indicadores['social_ambiental'] = {
                'hectares_recuperados': 0,
                'creditos_carbono': 0,
                'melhoria_qualidade_vida': 0
            }
            for match in soc_matches:
                valor = self._converter_numero(match if isinstance(match, str) else match[0])
                if valor > 100:
                    indicadores['social_ambiental']['creditos_carbono'] = max(
                        indicadores['social_ambiental']['creditos_carbono'], valor
                    )
                else:
                    indicadores['social_ambiental']['melhoria_qualidade_vida'] = max(
                        indicadores['social_ambiental']['melhoria_qualidade_vida'], valor
                    )
            campos_encontrados += 1
        
        # Indicadores Político-Público
        pol_matches = self._extrair_todos_matches(texto, self.padroes.POLITICO)
        if pol_matches:
            indicadores['politico'] = {
                'gestores_capacitados': 0,
                'aumento_transparencia': 0,
                'investimentos_captados': 0,
                'politicas_criadas': 0
            }
            for match in pol_matches:
                if isinstance(match, tuple):
                    valor = self._converter_valor_monetario(match[0])
                else:
                    valor = self._converter_numero(match) if not (',' in str(match) or '.' in str(match)) else self._converter_valor_monetario(match)
                
                if valor > 10000:  # Provavelmente valor monetário
                    indicadores['politico']['investimentos_captados'] = max(
                        indicadores['politico']['investimentos_captados'], valor
                    )
                elif valor > 100:  # Provavelmente quantidade de gestores
                    indicadores['politico']['gestores_capacitados'] = max(
                        indicadores['politico']['gestores_capacitados'], int(valor)
                    )
                elif valor < 100:  # Provavelmente percentual ou quantidade pequena
                    if valor < 50:
                        indicadores['politico']['politicas_criadas'] = max(
                            indicadores['politico']['politicas_criadas'], int(valor)
                        )
                    else:
                        indicadores['politico']['aumento_transparencia'] = max(
                            indicadores['politico']['aumento_transparencia'], valor
                        )
            campos_encontrados += 1
        
        dados.indicadores_encontrados = indicadores
        
        # ==================================================================
        # IDENTIFICA CAMPOS QUE PRECISAM SER PREENCHIDOS MANUALMENTE
        # ==================================================================
        
        campos_necessarios = []
        
        if dados.investimento_total == 0:
            campos_necessarios.append("investimento_total")
        if dados.beneficiarios == 0:
            campos_necessarios.append("beneficiarios")
        if not dados.nome_projeto:
            campos_necessarios.append("nome_projeto")
        if not indicadores.get('educacional'):
            campos_necessarios.append("indicadores_educacionais")
        if not indicadores.get('economico'):
            campos_necessarios.append("indicadores_economicos")
        if not indicadores.get('social_ambiental'):
            campos_necessarios.append("indicadores_social_ambiental")
        if not indicadores.get('politico'):
            campos_necessarios.append("indicadores_politico_publico")
        
        dados.campos_manuais_necessarios = campos_necessarios
        
        # Calcula confiança da extração
        dados.confianca_extracao = round((campos_encontrados / total_campos) * 100, 1)
        
        return dados
    
    def extrair_de_arquivo(self, caminho_arquivo: str) -> DadosExtraidos:
        """
        Extrai dados diretamente de um arquivo.
        
        Args:
            caminho_arquivo: Caminho para o arquivo PDF ou Word
            
        Returns:
            DadosExtraidos com os dados encontrados
        """
        texto = self.ler_arquivo(caminho_arquivo)
        return self.extrair_dados(texto, arquivo_origem=caminho_arquivo)
    
    # ==========================================================================
    # GERAÇÃO DE PROMPT PARA IA
    # ==========================================================================
    
    def gerar_prompt_ia(self, texto: str) -> str:
        """
        Gera prompt estruturado para análise por LLM.
        Pode ser usado com API do Claude, GPT, etc.
        """
        prompt = f"""
Analise o seguinte documento de projeto público e extraia as informações estruturadas para a metodologia VISIA.

DOCUMENTO:
{texto[:15000]}  # Limita para não exceder contexto

EXTRAIA AS SEGUINTES INFORMAÇÕES (responda em JSON):

1. IDENTIFICAÇÃO:
   - nome_projeto
   - descricao
   - orgao_responsavel
   - municipio
   - estado
   - investimento_total (valor em R$)

2. DIMENSÃO EDUCACIONAL:
   - alunos_impactados
   - melhoria_desempenho (%)
   - jovens_capacitados
   - taxa_empregabilidade (%)
   - investimento_educacional

3. DIMENSÃO ECONÔMICA:
   - empregos_gerados
   - renda_media
   - microcreditos_concedidos
   - valor_medio_credito
   - investimento_economico

4. DIMENSÃO SOCIAL E AMBIENTAL:
   - populacao_beneficiada
   - taxa_melhoria_qualidade_vida (%)
   - creditos_carbono_gerados
   - hectares_recuperados
   - investimento_social_ambiental

5. DIMENSÃO POLÍTICO-PÚBLICA:
   - gestores_capacitados
   - aumento_transparencia (%)
   - investimentos_captados
   - politicas_criadas
   - investimento_politico

Responda APENAS com o JSON estruturado, sem explicações adicionais.
Se um campo não for encontrado, use null.
"""
        return prompt


# ==============================================================================
# TESTE DO EXTRATOR
# ==============================================================================

if __name__ == "__main__":
    print("=" * 80)
    print("TESTE DO EXTRATOR VISIA")
    print("=" * 80)
    
    # Texto de exemplo para teste
    texto_teste = """
    PROJETO INCLUSÃO DIGITAL PARA TODOS
    
    Prefeitura Municipal de Campinas - SP
    
    RESUMO EXECUTIVO
    
    O Projeto Inclusão Digital para Todos visa capacitar 5.000 jovens em 
    tecnologia da informação, com investimento total de R$ 2,5 milhões 
    (dois milhões e quinhentos mil reais).
    
    Objetivos:
    - Capacitar 5.000 jovens em programação
    - Gerar 500 novos empregos na área de TI
    - Alcançar taxa de empregabilidade de 70%
    - Beneficiar 15.000 pessoas indiretamente
    
    Resultados Esperados:
    - Melhoria de 25% no desempenho escolar
    - Renda média dos formados: R$ 3.500
    - Redução de 15% na evasão escolar
    - 200 gestores públicos capacitados
    - Captação de R$ 500.000 em investimentos privados
    
    Impacto Ambiental:
    - Redução de 30% no uso de papel
    - 1.000 créditos de carbono gerados
    
    Duração: 24 meses
    """
    
    extrator = VisiaAIExtractor()
    dados = extrator.extrair_dados(texto_teste, "projeto_teste.txt")
    
    print(f"\n📄 Arquivo: {dados.arquivo_origem}")
    print(f"🔑 Hash: {dados.hash_documento}")
    print(f"📊 Confiança: {dados.confianca_extracao}%")
    
    print(f"\n--- DADOS EXTRAÍDOS ---")
    print(f"Nome: {dados.nome_projeto}")
    print(f"Investimento: R$ {dados.investimento_total:,.2f}")
    print(f"Beneficiários: {dados.beneficiarios:,}")
    print(f"Empregos: {dados.empregos:,}")
    print(f"Local: {dados.municipio} - {dados.estado}")
    print(f"Órgão: {dados.orgao_responsavel}")
    
    print(f"\n--- INDICADORES ENCONTRADOS ---")
    for dimensao, indicadores in dados.indicadores_encontrados.items():
        print(f"\n{dimensao.upper()}:")
        for ind, valor in indicadores.items():
            print(f"  • {ind}: {valor}")
    
    if dados.campos_manuais_necessarios:
        print(f"\n⚠️ CAMPOS PARA PREENCHIMENTO MANUAL:")
        for campo in dados.campos_manuais_necessarios:
            print(f"  • {campo}")
